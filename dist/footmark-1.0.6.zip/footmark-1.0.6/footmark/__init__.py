#
import logging
import logging.config
import os

from footmark.pyami.config import Config, FootmarkLoggingConfig, DefaultLoggingConfig

__version__ = '1.0.6'
Version = __version__  # for backware compatibility

def init_logging():
    try:
        Config().init_config()
        try:
            logging.config.fileConfig(os.path.expanduser(FootmarkLoggingConfig))
        except:
            logging.config.dictConfig(DefaultLoggingConfig)
    except:
        pass

init_logging()
log = logging.getLogger('footmark')


def connect_ecs(acs_access_key_id=None, acs_secret_access_key=None, **kwargs):
    """
    :type acs_access_key_id: string
    :param acs_access_key_id: Your AWS Access Key ID

    :type acs_secret_access_key: string
    :param acs_secret_access_key: Your AWS Secret Access Key

    :rtype: :class:`footmark.ecs.connection.ECSConnection`
    :return: A connection to Amazon's ECS
    """
    from footmark.ecs.connection import ECSConnection
    return ECSConnection(acs_access_key_id, acs_secret_access_key, **kwargs)


def connect_slb(acs_access_key_id=None, acs_secret_access_key=None, **kwargs):
    """
    :type acs_access_key_id: string
    :param acs_access_key_id: Your AWS Access Key ID

    :type acs_secret_access_key: string
    :param acs_secret_access_key: Your AWS Secret Access Key

    :rtype: :class:`footmark.ecs.connection.ECSConnection`
    :return: A connection to Amazon's SLB
    """
    from footmark.slb.connection import SLBConnection
    return SLBConnection(acs_access_key_id, acs_secret_access_key, **kwargs)


def connect_vpc(acs_access_key_id=None, acs_secret_access_key=None, **kwargs):
    """
    :type acs_access_key_id: string
    :param acs_access_key_id: Your AWS Access Key ID

    :type acs_secret_access_key: string
    :param acs_secret_access_key: Your AWS Secret Access Key

    :rtype: :class:`footmark.vpc.connection.ECSConnection`
    :return: A connection to Amazon's VPC
    """
    from footmark.vpc.connection import VPCConnection
    return VPCConnection(acs_access_key_id, acs_secret_access_key, **kwargs)

#acs_access_key_id = "LTAIV7yukr6Csf14"
#acs_secret_access_key = "it9TEJcJvnDyL5uB830fx1BQwzdNdd"
##instance_ids = "i-j6c5txh3q0wivxt5m807"
##group_id = "sg-j6c8bincxdak9xde7j0p"
#region_id = "cn-hongkong"
#snapshot_id = "s-j6chwdby6fkuzbxnsd82"
#disk_id = "d-2zea1m4frj5syfrvar12"
#instance_id = "i-rj95iytyo4d16kxqj58a"
##launch_permission =  {'user_ids': ['contact@click2cloud.net']}

###{'user_ids': ['user1', 'user2', 'user3', 'user4', 'user5']}
##image_id = 'm-rj9d7yk4rbq8e9va4odd'
#tags= [{'tag_key':'a1', 'tag_value':'1'},{'tag_key':'a2', 'tag_value':'2'},{'tag_key':'a3', 'tag_value':'3'}]
#mapping=[{'snapshot_id':'s-j6cjdk51ejf0mtdnb7bb','device':'/dev/xvdc'}]
#conn = connect_ecs(acs_access_key_id,acs_secret_access_key,region=region_id)
#result = conn.create_image(snapshot_id,'img1','1','desc of img',tags,None,mapping,None,'true',10)

#acs_access_key_id = "LTAIV7yukr6Csf14"
#acs_secret_access_key = "it9TEJcJvnDyL5uB830fx1BQwzdNdd"
#region_id = "us-west-1"
#conn = connect_slb(acs_access_key_id,acs_secret_access_key,region=region_id)
#load_balancer_id = "lb-2evkmagsr7apth28stns1"
#load_balancer_status = "active"
#result=conn.set_load_balancer_status(load_balancer_id=load_balancer_id, load_balancer_status=load_balancer_status)

#acs_access_key_id = "LTAIYkF7vqzLz5Zz"
#acs_secret_access_key = "jwibCDw18eD7SJHrGfasFcVGbjfdy5"
#region_id = "cn-hongkong"
#conn = connect_slb(acs_access_key_id,acs_secret_access_key,region=region_id)
#vserver_group_id = 'rsp-3ns8dfmm38urd'
#slb_id = 'lb-3ns4cetgwa5adn7r5ulcl'
#backend_servers = [
#                   {'ServerId': 'i-j6ci4rjdsy1xpmaizurs', 'Port': 8080}
#                  ]

#result=conn.remove_vserver_group(slb_id=slb_id,vserver_group_id=vserver_group_id, backend_servers=backend_servers) 
                                 
