# encoding: utf-8
"""
Represents a connection to the SLB service.
"""                    

import warnings

import six
import time
import json

from footmark.connection import ACSQueryConnection
from footmark.slb.regioninfo import RegionInfo
from footmark.slb.securitygroup import SecurityGroup
from footmark.exception import SLBResponseError


class SLBConnection(ACSQueryConnection):
    SDKVersion = '2014-05-15'
    DefaultRegionId = 'cn-hangzhou'
    DefaultRegionName = u'??'.encode("UTF-8")
    ResponseError = SLBResponseError

    def __init__(self, acs_access_key_id=None, acs_secret_access_key=None,
                 region=None, sdk_version=None, security_token=None):
        """
        Init method to create a new connection to SLB.
        """
        if not region:
            region = RegionInfo(self, self.DefaultRegionName,
                                self.DefaultRegionId)
        self.region = region
        if sdk_version:
            self.SDKVersion = sdk_version

        self.SLBSDK = 'aliyunsdkslb.request.v' + self.SDKVersion.replace('-', '')

        super(SLBConnection, self).__init__(acs_access_key_id,
                                            acs_secret_access_key,
                                            self.region, self.SLBSDK, security_token)
                                                                                 
    # C2C: Method added to create server load balancer
    def create_load_balancer(self, load_balancer_name=None, address_type=None, vswitch_id=None,
                             internet_charge_type=None, master_zone_id=None, slave_zone_id=None, bandwidth=None,
                             listeners=None, instance_ids=None,  validate_cert=None, tags=None, wait=None,
                             wait_timeout=None):
        """
        :type load_balancer_name: string
        :param load_balancer_name: Name to the server load balancer
        :type address_type: string
        :param address_type:  Address type. value: internet or intranet
        :type vswitch_id: string
        :param vswitch_id: The vswitch id of the VPC instance. This option is invalid if address_type parameter is
         provided as internet.
        :type internet_charge_type: string
        :param internet_charge_type: Charging mode for the public network instance
         Value: paybybandwidth or paybytraffic
        :type master_zone_id: string
        :param master_zone_id: Name of of availability zones to enable on this SLB
        :type slave_zone_id: string
        :param slave_zone_id: Name of of availability zones to enable on this SLB
        :type bandwidth: string
        :param bandwidth: Bandwidth peak of the public network instance charged per fixed bandwidth
        :type listeners: dict
        :param listeners: List of ports/protocols for this SLB to listen on
        :type instance_ids:
        :param instance_ids: A list of identifier for this instance or set of instances, so that the module will be
        :type validate_cert: string
        :param validate_cert: When set to "no", SSL certificates will not be validated. default: "yes"
        :type tags: list
        :param tags: A list of hash/dictionaries of load balancer tags, '[{tag_key:"value", tag_value:"value"}]',
         tag_key must be not null when tag_value isn't null
        :type wait: string
        :param wait: after execution of method whether it has to wait for some time interval
        :type wait_timeout: int
        :param wait_timeout: time interval of waiting
        :return: return the created load balancer details
        """

        params = {}
        results = []
        changed = False

        if load_balancer_name:
            self.build_list_params(params, load_balancer_name, 'LoadBalancerName')
        if address_type:
            self.build_list_params(params, address_type, 'AddressType')
        if vswitch_id:
            self.build_list_params(params, vswitch_id, 'VSwitchId')
        if internet_charge_type:
            self.build_list_params(params, internet_charge_type, 'InternetChargeType')
        if master_zone_id:
            self.build_list_params(params, master_zone_id, 'MasterZoneId')
        if slave_zone_id:
            self.build_list_params(params, slave_zone_id, 'SlaveZoneId')
        if bandwidth:
            self.build_list_params(params, bandwidth, 'Bandwidth')
                                   
        #load_balancer_tags = {}
        #tag_no = 1
        #if tags:
        #    for tag in tags:
        #        if tag:
        #            if 'tag_key' and 'tag_value' in tag:
        #                if (tag['tag_key'] is not None) and (tag['tag_value'] is not None):
        #                    self.build_list_params(load_balancer_tags, tag['tag_key'], 'Tag' + str(tag_no) + 'Key')
        #                    self.build_list_params(load_balancer_tags, tag['tag_value'], 'Tag' + str(tag_no) + 'Value')

        #                    load_balancer_tags.update({'Tag'+str(tag_no)+'Key': tag['tag_key']})
        #                    load_balancer_tags.update({'Tag'+str(tag_no)+'Value': tag['tag_value']})

        #                    tag_no += 1      
      
        #self.build_list_params(params, load_balancer_tags, 'Tags')
    
        try:
            results = self.get_status('CreateLoadBalancer', params)
            changed = True
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        else:
            slb_id = str(results[u'LoadBalancerId'])
            # if listener param is available then create listener
            if slb_id and listeners:
                for listener in listeners:
                    if listener:
                        if 'protocol' in listener:
                            # Add HTTP Listener to Load Balancer
                            if listener['protocol'] in ['http', 'Http', 'HTTP']:
                                listener_result = self.create_load_balancer_http_listener(slb_id, listener)
                                if listener_result:
                                    results.update({"http_listener_result": listener_result})

                            # Add HTTPS Listener to Load Balancer
                            if listener['protocol'] in ['https', 'Https', 'HTTPS']:
                                listener_result = self.create_load_balancer_https_listener(slb_id, listener)
                                if listener_result:
                                    results.update({"https_listener_result": listener_result})

                            # Add TCP Listener to Load Balancer
                            if listener['protocol'] in ['tcp', 'Tcp', 'TCP']:
                                listener_result = self.create_load_balancer_tcp_listener(slb_id, listener)
                                if listener_result:
                                    results.update({"tcp_listener_result": listener_result})

                            # Add UDP Listener to Load Balancer
                            if listener['protocol'] in ['udp', 'Udp', 'UDP']:
                                listener_result = self.create_load_balancer_udp_listener(slb_id, listener)
                                if listener_result:
                                    results.update({"udp_listener_result": listener_result})

                if instance_ids:
                    if len(instance_ids) > 0:     
                        backend_servers = []

                        # Add Backend Serves to Load Balancer
                        for backend_server_id in instance_ids:
                            backend_servers.append({"instance_id": backend_server_id, "weight": 100})

                        backend_server_result = self.add_backend_servers(slb_id, backend_servers)

                        if backend_server_result:
                            results.update({"backend_server_result": backend_server_result})

        if wait in ['yes', 'Yes', 'YES', 'true', 'True', 'TRUE'] and wait_timeout:
            time.sleep(wait_timeout)

        return changed, results

    def add_listeners(self, load_balancer_id, purge_listener=None, listeners=None):
        params = {}
        results = []
        deleted_listener = []

        try:
            # find out all listeners of the load balancer
            self.build_list_params(params, load_balancer_id, 'LoadBalancerId')
            slb_datails = self.get_status('DescribeLoadBalancerAttribute', params)

            # if purge_listener is true then delete existing listeners
            if purge_listener:
                if slb_datails:
                    if len(slb_datails[u'ListenerPortsAndProtocal'][u'ListenerPortAndProtocal']) > 0:
                        for slb_listener in slb_datails[u'ListenerPortsAndProtocal'][u'ListenerPortAndProtocal']:
                            params = {}
                            self.build_list_params(params, load_balancer_id, 'LoadBalancerId')
                            self.build_list_params(params, slb_listener[u'ListenerPort'], 'ListenerPort')
                            response = self.get_status('DeleteLoadBalancerListener', params)
                            deleted_listener.append(response)
                            
            # add listeners to load balancer
            if listeners:
                for listener in listeners:
                    if listener:
                        if 'protocol' in listener:
                            # Add HTTP Listener to Load Balancer
                            if listener['protocol'] in ['http', 'Http', 'HTTP']:
                                listener_result = self.create_load_balancer_http_listener(load_balancer_id, listener)
                                if listener_result:
                                    results.append({"http_listener_result": listener_result})

                            # Add HTTPS Listener to Load Balancer
                            if listener['protocol'] in ['https', 'Https', 'HTTPS']:
                                listener_result = self.create_load_balancer_https_listener(load_balancer_id, listener)
                                if listener_result:
                                    results.append({"https_listener_result": listener_result})

                            # Add TCP Listener to Load Balancer
                            if listener['protocol'] in ['tcp', 'Tcp', 'TCP']:
                                listener_result = self.create_load_balancer_tcp_listener(load_balancer_id, listener)
                                if listener_result:
                                    results.append({"tcp_listener_result": listener_result})

                            # Add UDP Listener to Load Balancer
                            if listener['protocol'] in ['udp', 'Udp', 'UDP']:
                                listener_result = self.create_load_balancer_udp_listener(load_balancer_id, listener)
                                if listener_result:
                                    results.append({"udp_listener_result": listener_result})

        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})

        return results     

    # C2C: Method added to create load balancer HTTP listener
    def create_load_balancer_http_listener(self, slb_id, listener):
        """
        :type slb_id: dict
        :param slb_id:  ID of Server Load Balancer
        :type listener: dict
        :param listener:
        :return:
        """

        params = {}
        results = []

        if listener:              
            self.build_list_params(params, slb_id, 'LoadBalancerId')
            if 'listener_port' in listener:
                self.build_list_params(params, listener['listener_port'], 'ListenerPort')
            if 'backend_server_port' in listener:
                self.build_list_params(params, listener['backend_server_port'], 'BackendServerPort')
            if 'bandwidth' in listener:
                self.build_list_params(params, listener['bandwidth'], 'Bandwidth')
            if 'scheduler' in listener:
                self.build_list_params(params, listener['scheduler'], 'Scheduler')
            if 'gzip' in listener:
                self.build_list_params(params, listener['gzip'], 'Gzip')

            if 'health_check' in listener:
                health_check = listener['health_check']                  
                self.build_list_params(params, "on", 'HealthCheck')
                if 'domain' in health_check:
                    self.build_list_params(params, health_check['domain'], 'HealthCheckDomain')
                if 'uri' in health_check:
                    self.build_list_params(params, health_check['uri'], 'HealthCheckURI')                 
                if 'connect_port' in health_check:
                    self.build_list_params(params, health_check['connect_port'], 'HealthCheckConnectPort')
                if 'healthy_threshold' in health_check:
                    self.build_list_params(params, health_check['healthy_threshold'], 'HealthyThreshold')
                if 'unhealthy_threshold' in health_check:
                    self.build_list_params(params, health_check['unhealthy_threshold'], 'UnhealthyThreshold')                
                if 'timeout' in health_check:
                    self.build_list_params(params, health_check['timeout'], 'HealthCheckTimeout')
                if 'interval' in health_check:
                    self.build_list_params(params, health_check['interval'], 'HealthCheckInterval')
                if 'http_code' in health_check:
                    self.build_list_params(params, health_check['http_code'], 'HealthCheckHttpCode')   

            if 'stickiness' in listener:
                stickiness = listener['stickiness']
                if 'enabled' in stickiness:
                    self.build_list_params(params, stickiness['enabled'], 'StickySession')
                if 'type' in stickiness:
                    self.build_list_params(params, stickiness['type'], 'StickySessionType')
                if 'cookie' in stickiness:
                    self.build_list_params(params, stickiness['cookie'], 'Cookie')
                if 'expiration' in stickiness:
                    self.build_list_params(params, stickiness['expiration'], 'CookieTimeout')

        try:
            results = self.get_status('CreateLoadBalancerHTTPListener', params)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})

        return results

    # C2C: Method added to create load balancer HTTPS listener
    def create_load_balancer_https_listener(self, slb_id, listener):
        """
        :type slb_id: dict
        :param slb_id:  ID of Server Load Balancer
        :type listener: dict
        :param listener:
        :return:
        """

        params = {}
        results = []

        if listener:              
            self.build_list_params(params, slb_id, 'LoadBalancerId')
            if 'listener_port' in listener:
                self.build_list_params(params, listener['listener_port'], 'ListenerPort')
            if 'backend_server_port' in listener:
                self.build_list_params(params, listener['backend_server_port'], 'BackendServerPort')
            if 'bandwidth' in listener:
                self.build_list_params(params, listener['bandwidth'], 'Bandwidth')
            if 'scheduler' in listener:
                self.build_list_params(params, listener['scheduler'], 'Scheduler')
            if 'ssl_certificate_id' in listener:
                self.build_list_params(params, listener['ssl_certificate_id'], 'ServerCertificateId')
            if 'gzip' in listener:
                self.build_list_params(params, listener['gzip'], 'Gzip')

            if 'health_check' in listener:
                health_check = listener['health_check']                  
                self.build_list_params(params, "on", 'HealthCheck')
                if 'domain' in health_check:
                    self.build_list_params(params, health_check['domain'], 'HealthCheckDomain')
                if 'uri' in health_check:
                    self.build_list_params(params, health_check['uri'], 'HealthCheckURI')                 
                if 'connect_port' in health_check:
                    self.build_list_params(params, health_check['connect_port'], 'HealthCheckConnectPort')
                if 'healthy_threshold' in health_check:
                    self.build_list_params(params, health_check['healthy_threshold'], 'HealthyThreshold')
                if 'unhealthy_threshold' in health_check:
                    self.build_list_params(params, health_check['unhealthy_threshold'], 'UnhealthyThreshold')                
                if 'timeout' in health_check:
                    self.build_list_params(params, health_check['timeout'], 'HealthCheckTimeout')
                if 'interval' in health_check:
                    self.build_list_params(params, health_check['interval'], 'HealthCheckInterval')
                if 'http_code' in health_check:
                    self.build_list_params(params, health_check['http_code'], 'HealthCheckHttpCode')   

            if 'stickiness' in listener:
                stickiness = listener['stickiness']
                if 'enabled' in stickiness:
                    self.build_list_params(params, stickiness['enabled'], 'StickySession')
                if 'type' in stickiness:
                    self.build_list_params(params, stickiness['type'], 'StickySessionType')
                if 'cookie' in stickiness:
                    self.build_list_params(params, stickiness['cookie'], 'Cookie')
                if 'expiration' in stickiness:
                    self.build_list_params(params, stickiness['expiration'], 'CookieTimeout')

        try:
            results = self.get_status('CreateLoadBalancerHTTPSListener', params)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})

        return results

    # C2C: Method added to create load balancer TCP listener
    def create_load_balancer_tcp_listener(self, slb_id, listener):
        """
        :type slb_id: dict
        :param slb_id:  ID of Server Load Balancer
        :type listener: dict
        :param listener:
        :return:
        """

        params = {}
        results = []

        if listener:              
            self.build_list_params(params, slb_id, 'LoadBalancerId')
            if 'listener_port' in listener:
                self.build_list_params(params, listener['listener_port'], 'ListenerPort')
            if 'backend_server_port' in listener:
                self.build_list_params(params, listener['backend_server_port'], 'BackendServerPort')
            if 'bandwidth' in listener:
                self.build_list_params(params, listener['bandwidth'], 'Bandwidth')
            if 'scheduler' in listener:
                self.build_list_params(params, listener['scheduler'], 'Scheduler')

            if 'health_check' in listener:
                health_check = listener['health_check']                  
                self.build_list_params(params, "on", 'HealthCheck')
                if 'domain' in health_check:
                    self.build_list_params(params, health_check['domain'], 'HealthCheckDomain')
                if 'uri' in health_check:
                    self.build_list_params(params, health_check['uri'], 'HealthCheckURI')                 
                if 'connect_port' in health_check:
                    self.build_list_params(params, health_check['connect_port'], 'HealthCheckConnectPort')
                if 'healthy_threshold' in health_check:
                    self.build_list_params(params, health_check['healthy_threshold'], 'HealthyThreshold')
                if 'unhealthy_threshold' in health_check:
                    self.build_list_params(params, health_check['unhealthy_threshold'], 'UnhealthyThreshold')                
                if 'timeout' in health_check:
                    self.build_list_params(params, health_check['timeout'], 'HealthCheckConnectTimeout')
                if 'interval' in health_check:
                    self.build_list_params(params, health_check['interval'], 'HealthCheckInterval')
                if 'http_code' in health_check:
                    self.build_list_params(params, health_check['http_code'], 'HealthCheckHttpCode')    

        try:
            results = self.get_status('CreateLoadBalancerTCPListener', params)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})

        return results

    # C2C: Method added to create load balancer UDP listener
    def create_load_balancer_udp_listener(self, slb_id, listener):
        """
        :type slb_id: dict
        :param slb_id:  ID of Server Load Balancer
        :type listener: dict
        :param listener:
        :return:
        """

        params = {}
        results = []

        if listener:              
            self.build_list_params(params, slb_id, 'LoadBalancerId')
            if 'listener_port' in listener:
                self.build_list_params(params, listener['listener_port'], 'ListenerPort')
            if 'backend_server_port' in listener:
                self.build_list_params(params, listener['backend_server_port'], 'BackendServerPort')
            if 'bandwidth' in listener:
                self.build_list_params(params, listener['bandwidth'], 'Bandwidth')
            if 'scheduler' in listener:
                self.build_list_params(params, listener['scheduler'], 'Scheduler')

            if 'health_check' in listener:
                health_check = listener['health_check']                  
                self.build_list_params(params, "on", 'HealthCheck')                              
                if 'connect_port' in health_check:
                    self.build_list_params(params, health_check['connect_port'], 'HealthCheckConnectPort')
                if 'healthy_threshold' in health_check:
                    self.build_list_params(params, health_check['healthy_threshold'], 'HealthyThreshold')
                if 'unhealthy_threshold' in health_check:
                    self.build_list_params(params, health_check['unhealthy_threshold'], 'UnhealthyThreshold')                
                if 'timeout' in health_check:
                    self.build_list_params(params, health_check['timeout'], 'HealthCheckConnectTimeout')
                if 'interval' in health_check:
                    self.build_list_params(params, health_check['interval'], 'HealthCheckInterval')

        try:
            results = self.get_status('CreateLoadBalancerUDPListener', params)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})

        return results

    # C2C: Method added to Add Backend Server to Load Balancer
    def add_backend_servers(self, load_balancer_id=None, backend_servers=None):
        """
        :type load_balancer_id: str
        :param load_balancer_id: ID of server load balancer
        :type backend_servers: list
        :param backend_servers: list of dictionary containing server Id and weight of  backend server instance
        :return: return status of an operation
        """

        weight_default = "100"
        params = {}
        results = []

        self.build_list_params(params, load_balancer_id, 'LoadBalancerId')

        backend_servers_list = []

        for backend_server in backend_servers:
            if 'instance_id' in backend_server:
                if 'weight' in backend_server:
                    backend_servers_list.append(
                        {"ServerId": backend_server['instance_id'], "Weight": str(backend_server['weight'])})
                else:
                    backend_servers_list.append(
                        {"ServerId": backend_server['instance_id'], "Weight": weight_default})

        if not len(backend_servers_list) > 0:
            results.append("Error: Provided Backend server information is not proper")
            return results

        backend_servers_json = json.dumps(backend_servers_list)
        self.build_list_params(params, backend_servers_json, 'BackendServers')

        try:
            response = self.get_status('AddBackendServers', params)
            results.append("Added Backend Server(s) successfully. Please note that if BackendServers contains"
                           " ECS instance already added, the ECS instance will be ignored, without any issue being reported.")
            results.append("Following are the currently added backend server details:")

            results.extend(response['BackendServers']['BackendServer'])
            # for backend_server in response['BackendServers']['BackendServer']:
            #   results.append("ServerId: " + backend_server['ServerId'])
            #  results.append("Weight: " + str(backend_server['Weight']))

        except Exception as ex:
            error_code = ex.error_code
            msg = ex.message
            results.append("Failed to add backend servers.")
            results.append("Error Code: " + error_code)
            results.append("Message: " + msg)

        return results

    # C2C: Method added to remove Backend Server in Load Balancer
    def remove_backend_servers(self, load_balancer_id=None, backend_server_ids=None):
        """
        :type load_balancer_id: str
        :param load_balancer_id: ID of server load balancer
        :type backend_servers: list
        :param backend_servers: list of IDs of backend server instance
        :return: return status of an operation
        """
        params = {}
        results = []

        self.build_list_params(params, load_balancer_id, 'LoadBalancerId')

        backend_servers_json = json.dumps(backend_server_ids)

        self.build_list_params(params, backend_servers_json, 'BackendServers')

        try:
            response = self.get_status('RemoveBackendServers', params)
            results.append("Removal of Backend Server(s) successful.")

            if len(response['BackendServers']['BackendServer']) > 0:
                results.append("Following are the currently added backend server details:")
                results.extend(response['BackendServers']['BackendServer'])

        except Exception as ex:
            error_code = ex.error_code
            msg = ex.message
            results.append("Failed to remove backend servers.")
            results.append("Error Code: " + error_code)
            results.append("Message: " + msg)

        return results

    # C2C: Method added to set Backend Server to Load Balancer
    def set_backend_servers(self, load_balancer_id=None, backend_servers=None):
        """
        :type load_balancer_id: str
        :param load_balancer_id: ID of server load balancer
        :type backend_servers: list
        :param backend_servers: list of dictionary containing server Id and weight of  backend server instance
        :return: return status of an operation
        """

        weight_default = "100"
        params = {}
        results = []

        self.build_list_params(params, load_balancer_id, 'LoadBalancerId')

        backend_servers_list = []

        for backend_server in backend_servers:
            if 'instance_id' in backend_server:
                if 'weight' in backend_server:
                    backend_servers_list.append(
                        {"ServerId": backend_server['instance_id'], "Weight": str(backend_server['weight'])})
                else:
                    results.append("Error in setting backend server information. "
                                   "Please provide weight for backend server id " + backend_server['instance_id'])
                    return results

        if not len(backend_servers_list) > 0:
            results.append("Error: Provided Backend server information is not proper")
            return results

        backend_servers_json = json.dumps(backend_servers_list)
        self.build_list_params(params, backend_servers_json, 'BackendServers')

        try:
            response = self.get_status('SetBackendServers', params)
            results.append("Updated Backend Server(s) information successfully.")
            if len(response['BackendServers']['BackendServer']) > 0:
                results.append("Following are the currently added backend server details:")
                results.extend(response['BackendServers']['BackendServer'])

        except Exception as ex:
            error_code = ex.error_code
            msg = ex.message
            results.append("Failed to set backend servers.")
            results.append("Error Code: " + error_code)
            results.append("Message: " + msg)

        return results

    def describe_backend_servers_health_status(self, load_balancer_id=None, listener_ports=None):
        """
        :type load_balancer_id: str
        :param load_balancer_id: ID of server load balancer
        :type listener_ports: int
        :param listener_ports: list of Ports used by the Server Load Balancer instance frontend for health check
        :return:
        """
        params = {}
        results = []
        ports_available = False

        self.build_list_params(params, load_balancer_id, 'LoadBalancerId')

        if listener_ports:
            if len(listener_ports) > 0:
                ports_available = True

        if ports_available:
            for port in listener_ports:
                self.build_list_params(params, port, 'ListenerPort')
                try:
                    response = self.get_status('DescribeHealthStatus', params)
                    if len(response['BackendServers']['BackendServer']) > 0:
                        results.extend(response['BackendServers']['BackendServer'])
                        # for backend_server in response['BackendServers']['BackendServer']:
                        # results.append("Server Id: " + backend_server['ServerId'])
                        # results.append("Server Health Status: " + str(backend_server['ServerHealthStatus']))
                    else:
                        results.append("No listener or backend servers available for port " + str(port))

                except Exception as ex:
                    error_code = ex.error_code
                    msg = ex.message
                    results.append("Failed to retrieve backend servers' health status for port " + str(port))
                    results.append("Error Code: " + error_code)
                    results.append("Message: " + msg)
        else:
            try:
                response = self.get_status('DescribeHealthStatus', params)
                if len(response['BackendServers']['BackendServer']) > 0:
                    results.extend(response['BackendServers']['BackendServer'])
                    # for backend_server in response['BackendServers']['BackendServer']:
                    # results.append("Server Id: " + backend_server['ServerId'])
                    # results.append("Server Health Status: " + backend_server['ServerHealthStatus'])
                else:
                    results.append("No listener or backend servers available for slb id " + load_balancer_id)

            except Exception as ex:
                error_code = ex.error_code
                msg = ex.message
                results.append("Failed to retrieve backend servers' health status for slb id " + load_balancer_id)
                results.append("Error Code: " + error_code)
                results.append("Message: " + msg)

        return results


    def set_load_balancer_status(self, load_balancer_id, load_balancer_status):
        """
        Method added to Set Load Balancer Status
        :type slb_id: List
        :param slb_id: ID of server load balancer
        :type status: String
        :param status: Status of an Server Load Balancer instance
            Value：inactive | active
        :return: return name of the operating interface, which is
            specified in the system
        """

        params = {}
        results = []
        changed = False

       
        self.build_list_params(params, load_balancer_id, 'LoadBalancerId')        
        
        self.build_list_params(params, load_balancer_status, 'LoadBalancerStatus')
        
        try:
            result = self.get_status('SetLoadBalancerStatus', params)
            results.append(result)
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})

        return changed, results

    def set_load_balancer_name(self, attributes):
        """
        Method added to Set Load Balancer Name
        :type attributes: List
        :param attributes: A list of hash/dictionaries of SLB instance attributes
              - slb_id (required:true; default: null )
              - name (required:true)
        :return: return name of the operating interface, which is
            specified in the system
        """
        results = []
        changed = False
        if attributes:
            for attribute in attributes:
                if attribute:
                    params = {}
                    if 'slb_id' in attribute:
                        self.build_list_params(params, attribute['slb_id'], 'LoadBalancerId')
                    if 'name' in attribute:
                        self.build_list_params(params, attribute['name'], 'LoadBalancerName')                   
                    try:
                        result = self.get_status('SetLoadBalancerName', params)
                        results.append(result)
                        changed = True
                    except Exception as ex:
                        error_code = ex.error_code
                        error_msg = ex.message
                        results.append({"Error Code": error_code, "Error Message": error_msg})
        return changed,results

    def delete_load_balancer(self, slb_id):
        """
        Method added to Delete Load Balancer

        :type slb_id: dict
        :param slb_id: Id of the server load balancer
        :return: Return status of Operation
        """
        params = {}
        results = []
        changed = False

        self.build_list_params(params, slb_id, 'LoadBalancerId')
        try:
            results = self.get_status('DeleteLoadBalancer', params)
            
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})

        return changed, results    
    
    def modify_slb_internet_spec(self, load_balancer_id, internet_charge_type=None, bandwidth=None):
        """
        :type instance_ids: list
        :param instance_ids: list of the unique ID of an Server Load Balancer instance

        :type internet_charge_type: str
        :param internet_charge_type: Charging mode for the public network instance

        :type bandwidth: str
        :param bandwidth: Bandwidth peak of the public network instance charged per fixed bandwidth

        :return: returns the list of the status of the operation performed
        """

        params = {}
        results = []
        changed = False

        if internet_charge_type:
            self.build_list_params(params, internet_charge_type, 'InternetChargeType')

        if bandwidth:
            self.build_list_params(params, bandwidth, 'Bandwidth')

        self.build_list_params(params, load_balancer_id, 'LoadBalancerId')

        try:
            response = self.get_status('ModifyLoadBalancerInternetSpec', params)
            changed = True
            results.append("Load Balancer with Id " + load_balancer_id + " successfully updated")
        except Exception as ex:
            error_code = ex.error_code
            msg = ex.message
            results.append("Update failed for '" + load_balancer_id + "' with error code '" + error_code + "' because " + msg)

        return changed, results


    def describe_load_balancer_attribute(self, load_balancer_id):
        """

        :param load_balancer_id: id of the load balancer
        :return: load balance attributes in dictionary format if found else None
        """

        params = {}
        load_balancer_info = None

        self.build_list_params(params, load_balancer_id, 'LoadBalancerId')

        try:
            response = self.get_status('DescribeLoadBalancerAttribute', params)
            load_balancer_info = response
        except Exception as ex:
            return load_balancer_info

        return load_balancer_info


    # region Virtual Server Group
    def create_vserver_group(self, slb_id, vserver_group_name, backend_servers):
        """
        
        Method to Create Vserver Group
        
        :type slb_id: string
        :param slb_id: Virtual server LoadBalancer Id
        :type vserver_group_name: string
        :param vserver_group_name: Virtual server group name, where you can rename it
        :type backend_servers:  List of hash/dictionary
        :param backend_servers:
          - List of hash/dictionary of backend servers to add in
          - '[{"key":"value", "key":"value"}]', keys allowed:
            - instance_id (required:true, description: Unique id of Instance to add)
            - port (required:true, description: The back-end server using the port, range: 1-65535)
            - weight (required:true; default: 100, description: Weight of the backend server, in the range of 1-100 )
                               
        :return: it return public parameters with ,VServerGroupId The unique identifier for the virtual server.
                 and BackendServers Array format, list of back-end servers in the virtual server group.
                 The structure of the elements in the list is detailed in BackendServer
        """
        params = {}
        results = []
        backend_serverlist = []
        vservergroupid = None
        backendservers = None
        changed = False
        if slb_id:
            self.build_list_params(params, slb_id, 'LoadBalancerId')
        if vserver_group_name:
            self.build_list_params(params, vserver_group_name, 'VServerGroupName')
        if backend_servers:
            for servers in backend_servers:
                backend_serverlist.append({
                        'ServerId': servers['ServerId'],
                        'Port': servers['Port'],
                        'Weight': servers['Weight']
                    })
                                    
            self.build_list_params(params, json.dumps(backend_serverlist), 'BackendServers')
                
        try:
            results = self.get_status('CreateVServerGroup', params)
            backendservers = results[u'BackendServers']
            vservergroupid = results[u'VServerGroupId']
            changed = True
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append("Error Code:" + error_code + " ,Error Message:" + error_msg)
        return results, changed, vservergroupid, backendservers

    def set_vservergroup_attribute(self, vserver_group_id, vserver_group_name=None, backend_servers=None):
        """
        Set a virtual server group, change the name for an existing virtual server group, or change the  weight of an existing back-end server.
        :param vserver_group_id: The virtual server group ID
        :param vserver_group_name:Virtual server group name, where you can rename it
        :param backend_servers:  - List of hash/dictionary of backend servers to add in
          - '[{"key":"value", "key":"value"}]', keys allowed:
            - instance_id (required:true, description: Unique id of Instance to add)
            - port (required:true, description: The back-end server using the port, range: 1-65535)
            - weight (required:true; default: 100, description: Weight of the backend server, in the range of 1-100 )
        :return: VServerGroupId	String	The unique identifier for the virtual server group
                 VServerGroupName	String	Virtual server group name
                 BackendServers	List	Array format, returns the operation is successful,
                 the virtual server group all the back-end server list,
                 the list of elements in the structure see BackendServer
        """
        params = {}
        results = []
        backend_serverlist = []
        changed = False
        vservergroupid = None
        backendservers = None
        vservergroupname = None
    
        if vserver_group_id:
            self.build_list_params(params, vserver_group_id, 'VServerGroupId')
        if vserver_group_name:
            self.build_list_params(params, vserver_group_name, 'VServerGroupName')
        if backend_servers:
            for servers in backend_servers:
                backend_serverlist.append({
                    'ServerId': servers['ServerId'],
                    'Port': servers['Port'],
                    'Weight': servers['Weight']
                })
        
            self.build_list_params(params, json.dumps(backend_serverlist), 'BackendServers')
        try:
            results = self.get_status('SetVServerGroupAttribute', params)
            changed = True
            vservergroupid = results[u'VServerGroupId']
            vservergroupname = results[u'VServerGroupName']
            backendservers = results[u'BackendServers']
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append("Error Code:" + error_code + " ,Error Message:" + error_msg)
        return changed, results, vservergroupid, vservergroupname, backendservers

    def add_vservergroup_backend_server(self, vserver_group_id, backend_servers):
        """
        Add a back-end server in a virtual server group, add a set of back-end servers to a specific virtual server group in the SLB,
        and return a list of back-end servers in that virtual server group.
        :param vserver_group_id: The unique identifier for the virtual server group
        :param backend_servers:  - List of hash/dictionary of backend servers to add in
          - '[{"key":"value", "key":"value"}]', keys allowed:
            - instance_id (required:true, description: Unique id of Instance to add)
            - port (required:true, description: The back-end server using the port, range: 1-65535)
            - weight (required:true; default: 100, description: Weight of the backend server, in the range of 1-100 )
        :return: VServerGroupId	String	The unique identifier for the virtual server group
                 BackendServers	List	Array format, returns the operation is successful,
                 the virtual server group all the back-end server list, the list of elements in the structure see BackendServer
        """
        params = {}
        changed = False
        results = []
        backend_serverlist = []
        vservergroupid = None
        backendservers = None
        if vserver_group_id:
            self.build_list_params(params, vserver_group_id, 'VServerGroupId')
        if backend_servers:
            for servers in backend_servers:
                backend_serverlist.append({'ServerId': servers['ServerId'],
                                           'Port': servers['Port'],
                                           'Weight': servers['Weight']})
                
            self.build_list_params(params, json.dumps(backend_serverlist), 'BackendServers')
        try:
            results = self.get_status('AddVServerGroupBackendServers', params)
            backendservers = results[u'BackendServers']
            vservergroupid = results[u'VServerGroupId']
            changed = True
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append("Error Code:" + error_code + " ,Error Message:" + error_msg)
        return changed, results, vservergroupid, backendservers

    def remove_vserver_group(self, slb_id, vserver_group_id, backend_servers):
        """        
        Method to Remove Vserver Group        
        :type slb_id: string
        :param slb_id: Virtual server group name
        :type vserver_group_id: string
        :param vserver_group_id: Virtual server group Id
        :type backend_servers:  List of hash/dictionary
        :param backend_servers:
          - List of hash/dictionary of backend servers to add in
          - '[{"key":"value", "key":"value"}]', keys allowed:
            - instance_id (required:true, description: Unique id of Instance to add)
            - port (required:true, description: The back-end server using the port, range: 1-65535)          
                               
        :return: it return public parameters with ,VServerGroupId The unique identifier for the virtual server.
                 and BackendServers Array format, list of back-end servers in the virtual server group.
                 The structure of the elements in the list is detailed in BackendServer
        """
        
        params = {}
        results = []
        changed = False
        backend_serverlist = []

        if slb_id:
            self.build_list_params(params, slb_id, 'LoadBalancerId')        
        if vserver_group_id:
            self.build_list_params(params, vserver_group_id, 'VServerGroupId')
        if backend_servers:
            for servers in backend_servers:
                backend_serverlist.append({'ServerId': servers['ServerId'], 'Port': servers['Port']})
            self.build_list_params(params, json.dumps(backend_serverlist), 'BackendServers')

        try: 
            results = self.get_status('RemoveVServerGroupBackendServers', params)
            changed = True
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return results

    def modify_vserver_group(self, vserver_group_id, old_backend_servers, new_backend_servers):
        """        
        Method to Modify Vserver Group        
        :type vserver_group_id: string
        :param vserver_group_id: Virtual server group Id
        :type old_backend_servers: List of hash/dictionary
        :param old_backend_servers: 
          - List of hash/dictionary of backend servers to add in
          - '[{"key":"value", "key":"value"}]', keys allowed:
            - instance_id (required:true, description: Unique id of Instance to add)
            - port (required:true, description: The back-end server using the port, range: 1-65535)
        :type new_backend_servers:  List of hash/dictionary
        :param new_backend_servers:
          - List of hash/dictionary of backend servers to add in
          - '[{"key":"value", "key":"value"}]', keys allowed:
            - instance_id (required:true, description: Unique id of Instance to add)
            - port (required:true, description: The back-end server using the port, range: 1-65535)
            - weight (required:true; default: 100, description: Weight of the backend server, in the range of 1-100 )          
                               
        :return: Change the virtual back-end servers in the server group, in a particular SLB virtual server 
                 group by adding / deleting the back-end server to replace the current server group, the group returned 
                 to the virtual server back-end server list.
        """
        
        params = {}
        results = []
        changed = False

        if vserver_group_id:
            self.build_list_params(params, vserver_group_id, 'VServerGroupId')       
        if old_backend_servers:
            for old in old_backend_servers:
                old_backend_serverlist = []

                old_backend_serverlist.append({'ServerId': old['ServerId'],'Port': old['Port']})
            self.build_list_params(params, json.dumps(old_backend_serverlist), 'OldBackendServers')
        if new_backend_servers:
            for new in new_backend_servers:
                new_backend_serverlist = []

                new_backend_serverlist.append({'ServerId': new['ServerId'],'Port': new['Port'],'Weight': new['Weight']})
            self.build_list_params(params, json.dumps(new_backend_serverlist), 'NewBackendServers')

        try: 
            results = self.get_status('ModifyVServerGroupBackendServers', params)
            changed = True
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append({"Error Code": error_code, "Error Message": error_msg})
        return changed, results

    def delete_vserver_group(self, vserver_group_id):
        """
        Delete specified by VServerGroupId virtual server group.
        :param vserver_group_id:Uniquely identifies the virtual server group.
        Note: If the virtual server group is referenced, can not be deleted

        :return: Request id
        """
        params = {}
        results = []
        changed = False
        if vserver_group_id:
            self.build_list_params(params, vserver_group_id, 'VServerGroupId')
        try:
            results = self.get_status('DeleteVServerGroup', params)
            changed = True
        except Exception as ex:
            error_code = ex.error_code
            error_msg = ex.message
            results.append("Error Code:" + error_code + " ,Error Message:" + error_msg)
        return changed, results
    # endregion



